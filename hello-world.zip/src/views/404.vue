<template>
  <img src="../assets/404.png"  style="width: 90%; height: 90%"/>
</template>

<script>
export default {
  name: "NotFound"
}
</script>

<style scoped>

</style>