<template>
  <el-card style="width: 500px; ">
    <el-form label-width="80px" size="small">
      <el-form-item label="姓名" >
        <el-input v-model="form.stuname" autocomplete="off"></el-input>
      </el-form-item>
      <el-form-item label="学号" >
        <el-input v-model="form.stunumber" autocomplete="off"></el-input>
      </el-form-item>
      <el-form-item label="学院" >
        <el-input v-model="form.college" autocomplete="off"></el-input>
      </el-form-item>
      <el-form-item label="专业" >
        <el-input v-model="form.subject" autocomplete="off"></el-input>
      </el-form-item>
      <el-form-item label="论文数量" >
        <el-input v-model="form.counter" autocomplete="off"></el-input>
      </el-form-item>
      <el-form-item label="电话号码" >
        <el-input v-model="form.tel" autocomplete="off"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="save">确 定</el-button>
      </el-form-item>
    </el-form>
  </el-card>
</template>

<script>
export default {
  name: "Person",
  data() {
    return {
      form: {},
      user: localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : {}
    }
  },
  created() {
    this.request.get("/user/username/" + this.user.stunumber).then(res =>{
      if(res.code === '200') {
        this.form = res.data
      }
    })
  },
  methods: {
    save() {
      this.request.post("/user", this.form).then(res => {
        if (res.data) {
          this.$message.success("保存成功")
          this.$router.push("/user")
        } else {
          this.$message.error("保存失败")
        }
      })
    },
  }
}
</script>

<style scoped>

</style>