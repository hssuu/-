import Vue from 'vue'
import VueRouter from 'vue-router'
import HomeView from '../views/Manage.vue'

Vue.use(VueRouter)

const routes = [
    {
        path: '/login',
        name: 'Login',
        component: () => import('../views/Login.vue')
    },
    {
        path: '/register',
        name: 'Register',
        component: () => import('../views/Register.vue')
    },
    {
        path: '*',
        name: '404',
        component: () => import('../views/404.vue')
    },
]

const router = new VueRouter({
    mode: 'history',
    base: process.env.BASE_URL,
    routes
})

//刷新界面会导致页面路由重置
export const setRoutes = () => {
    const storeMenus = localStorage.getItem("menus");
    if (storeMenus) {
        //拼装动态路由
        const manageRoute = { path: '/', name:'Manage', component: () => import('../views/Manage.vue'), redirect: "/home", children: [] }
        const menus = JSON.parse(storeMenus)
        menus.forEach(item => {
            if (item.path) { //当且仅当path不为空的时候才去设置路由
                let itemMenu = { path: item.path.replace("/", ""), name: item.name, component: () => import('../views/' + item.pagePath + '.vue')}
                manageRoute.children.push(itemMenu)
            } else if (item.children.length){
                item.children.forEach(item => {
                    if (item.path) {
                        let itemMenu = { path: item.path.replace("/", ""), name: item.name, component: () => import('../views/' + item.pagePath + '.vue')}
                        manageRoute.children.push(itemMenu)
                    }
                })
            }
        })
        //获取当前的路由对象数组
        const currentRouteNames = router.getRoutes().map(v => v.name)
        if (!currentRouteNames.includes('Manage')) {
            //动态添加到现在的路由对象中去
            router.addRoute(manageRoute)
        }

    }
}

//重置我就再set一次路由
setRoutes()

export default router
